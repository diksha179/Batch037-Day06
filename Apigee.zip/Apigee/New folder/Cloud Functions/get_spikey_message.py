def get_spikey_message(request):
    return 'Greetings from Spikey Sales!'